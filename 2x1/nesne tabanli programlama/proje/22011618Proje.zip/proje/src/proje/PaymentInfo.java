package proje;

import java.io.Serializable;

public class PaymentInfo implements Serializable{
	private final double discountRatio;
	private double recievedPayment;
	
	public PaymentInfo(double discountRatio) {
		this.discountRatio = discountRatio;
		this.recievedPayment = 0;
	}
	
	public void increasePayment(double amount) {
		recievedPayment += amount;
	}
	
	public double getRecievedPayment() {
		return recievedPayment;
	}

	public double getDiscountRatio() {
		return discountRatio;
	}

	@Override
	public String toString() {
		return "PaymentInfo [discountRatio=" + discountRatio + ", recievedPayment=" + recievedPayment + "]";
	}
	
	
}
