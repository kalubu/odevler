package proje;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class DistributorTest {
	private Distributor dist;
	@Before
	public void setUp() throws Exception {
		dist = new Distributor();
		dist.addJournal(new Journal("Dergi", "123",3,100));
		dist.addSubscriber(new Individual("Ahmet", "Istanbul", "12345", 8,2027,532));

	}

	@Test
	public void testJournals() {
		assertEquals(dist.searchJournal("123").getName(), "Dergi");
	}

	@Test
	public void testSubscribers() {
		assertEquals(dist.searchSubscriber("Ahmet").getAddress(), "Istanbul");
	}

}
