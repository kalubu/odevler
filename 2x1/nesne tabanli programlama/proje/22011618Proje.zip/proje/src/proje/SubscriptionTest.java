package proje;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class SubscriptionTest {
	private Subscription sub;
	@Before
	public void setUp() throws Exception {
		sub = new Subscription(new DateInfo(8,7,2023),new PaymentInfo(20),1,new Journal("Dergi", "123",3,100),new Individual("Ahmet", "Istanbul", "12345", 8,2027,532));
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testAcceptPayment() {
		sub.acceptPayment(100);
		assertEquals(sub.getPayment().getRecievedPayment(),100,0.2);
	}

	@Test
	public void testToString() {
		String str = "name=Ahmet, address=Istanbul, startMonth=8, endMonth=7, startYear=2023, copies=1, journal=Journal [name=Dergi, issn=123, frequency=3, issuePrice=100.0]";
		assertEquals(str,sub.toString());
	}

}
