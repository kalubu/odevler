package proje;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CorporationTest {
	private Corporation corporation;
	@Before
	public void setUp() throws Exception {
		corporation = new Corporation("ABC Company", "Istanbul", 1, "A Bank", 3, 10,2023, 5000);
	}	

	@Test
	public void testToString() {
		String str = "name=ABC Company, address=Istanbul";
		assertEquals(str,corporation.toString());
	}

	public void testBilling() {
		String str="Corporation [Name:ABC Company, Address:Istanbul, bankCode=1, bankName=A Bank, issueDay=3, issueMonth=10, issueYear=2023, accountNumber=5000]";
		assertEquals(str,corporation.getBillingInformation());
	}
}
