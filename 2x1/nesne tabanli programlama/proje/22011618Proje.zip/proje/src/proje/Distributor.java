package proje;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Vector;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class Distributor implements Serializable, Runnable{
	private Hashtable<String,Journal> journals = new Hashtable<>();
	private Vector<Subscriber> subscribers = new Vector<>();
	private ArrayList<Subscription> subscriptions = new ArrayList<>();
	
	private int expM;
	private int expY;
	private int yearStart; 
	private int yearEnd;
	private String reportText;
	public boolean addJournal(Journal journal) {
		try {
			if(journals.containsKey(journal.getIssn())) {
				journal = null;
				return false;
			}
			else {
				journals.put(journal.getIssn(), journal);
				return true;
			}
				
		}
		catch(Exception e) {
			return false;
		}
		
	}
	
	public Journal searchJournal(String issn) {
		return journals.get(issn);
	}
	
	public boolean addSubscriber(Subscriber sub) {
		try{
			for(Subscriber s: subscribers) {
				if(s.getName().equals(sub.getName())) {
					sub = null;
					return false;
				}
			}
			subscribers.add(sub);
			return true;
			}
		catch(Exception e){
			return false;
		}
	}
	
	public Subscriber searchSubscriber(String name) {
		for(Subscriber s: subscribers) {
			if(s.getName().equals(name) ) {
				return s;
			}
		}
		return null;
	}
	
	public boolean addSubscription(String issn, Subscriber sub, Subscription subs) {
		int f=0;
		if(subscribers.contains(subs.getSubscriber()) && journals.containsKey(issn)) {
			for(Subscription s : subscriptions) {
				if(s.getSubscriber() == sub && s.getJournal().getIssn().equals(issn)) {
					journals.get(issn).addSubscription(s);
					subs=null;
					f=1;
				}
			}
			if(f==0) {
				subscriptions.add(subs);
			}
			
			return true;
		}
		else {
			return false;
		}
			

	}
	public boolean isValidDate(int month, int year, Subscription s) {
		if(s.getDates().getStartYear() > year) {
			return false;
		}
		else {
			if(s.getDates().getStartYear() == year){
				if(s.getDates().getStartMonth() > month) {
					return false;
				}
				else {
					return true;
				}
			}
			else {
				if(s.getDates().getEndMonth() >= month) {
					return true;
				}
				else {
					return false;
				}
			}
		}
	}
	public String listAllSendingOrders(int month,int year) {
		String str ="";
		for(Subscription s : subscriptions) {
			System.out.println(s.canSend(month) && isValidDate(month, year, s));
			if(s.canSend(month) && isValidDate(month, year, s)) {
				str += "Name:" + s.getSubscriber().getName() + " Address:" + s.getSubscriber().getAddress() + " Journal:" + s.getJournal().getName() + "\n";
			}
				
		}
		if(str.equals("")) {
			return "No order to be sent";
		}
		else {
			return str;
		}
	}
	
	public String listSendingOrders(String issn,int month,int year){
		String str ="";
		for(Subscription s : subscriptions) {
			if(s.getJournal().getIssn().equals(issn)) {
				if(s.canSend(month) && isValidDate(month, year, s)) {
					str += "Name:" + s.getSubscriber().getName() + " Address:" + s.getSubscriber().getAddress() + " Journal:" + s.getJournal().getName() + "\n";
				}
				
			}
		}
		if(str.equals("")) {
			return "No order to be sent";
		}
		else {
			return str;
		}
	}
	
	public String listIncompletePayments() {
		String str ="";
		for(Subscription s : subscriptions) {
			if(s.getJournal().getFrequency()*s.getJournal().getIssuePrice()*(100-s.getPayment().getDiscountRatio())/100*s.getCopies() > s.getPayment().getRecievedPayment() ) {
				str += "Name:" + s.getSubscriber().getName() + " Address:" + s.getSubscriber().getAddress() + " Journal:" + s.getJournal().getName() + " Payment left:" + Double.toString(s.getJournal().getFrequency()*s.getJournal().getIssuePrice()*(100-s.getPayment().getDiscountRatio())/100*s.getCopies() - s.getPayment().getRecievedPayment()) + "\n";
			}
		}
		if(str.equals("")) {
			return "There is no incomplete Payments";
		}
		else {
			return str;
		}
	}
	public Subscription searchSubscription(String name, String issn) {
		for(Subscription s : subscriptions) {
			if(s.getSubscriber().getName().equals(name) && s.getJournal().getIssn().equals(issn)) {
				return s;
			}
		}
		return null;
	}
	
	public String listSubscriptions(String subname) {
		String str="";
		for(Subscription s : subscriptions) {
			if(s.getSubscriber().getName().equals(subname)) {
				str += s.toString() + "\n";
			}
		}
		if(str.equals("")) {
			return "Not found";
		}
		else {
			return str;
		}
	}
	
	public Hashtable<String, Journal> getJournals() {
		return journals;
	}

	public Vector<Subscriber> getSubscribers() {
		return subscribers;
	}

	public ArrayList<Subscription> getSubscriptions() {
		return subscriptions;
	}

	public String listSubscriptionsISSN(String text) {
		String str="";
		for(Subscription s : subscriptions) {
			if(s.getJournal().getIssn().equals(text)) {
				str += s.toString() + "\n";
			}
		}
		if(str.equals("")) {
			return "Not found";
		}
		else {
			return str;
		}
	}
	
	public synchronized void loadState(String fileName) {
		  try {
	            FileInputStream fileIn = new FileInputStream(fileName);
	            ObjectInputStream in = new ObjectInputStream(fileIn);
	            journals = (Hashtable<String,Journal>) in.readObject();
	            subscribers = (Vector<Subscriber>) in.readObject();
	            subscriptions = (ArrayList<Subscription>) in.readObject();
	            in.close();
	            fileIn.close();
	        } catch (IOException i) {
	            i.printStackTrace();
	            return;
	        } catch (ClassNotFoundException c) {
	            System.out.println("Employee class not found");
	            c.printStackTrace();
	            return;
	        }
	}
	public synchronized void saveState(String fileName) {
        try {
            FileOutputStream fileOut = new FileOutputStream(fileName);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(journals);
            out.writeObject(subscribers);
            out.writeObject(subscriptions);
            out.close();
            fileOut.close();
        } catch (IOException i) {
            i.printStackTrace();
        }
	}
	public void report(int expM, int expY, int yearStart, int yearEnd) {
		this.expM=expM;
		this.expY=expY;
		this.yearStart=yearStart;
		this.yearEnd=yearEnd;

	}
	@Override
	public void run() {
		String str="Expiring subs:\n";
		for(Subscription s: subscriptions) {
			if(s.getDates().getEndMonth() < expM && s.getDates().getStartYear()+1 <= expY) {
				str += s.toString() + "\n";
			}
		}
		for(int i=0;i<yearEnd-yearStart;i++) {
			int annual=0;
			str += yearStart+i +"-"+ (yearStart+i+1) + ": ";
			for(Subscription s: subscriptions) {
				if(s.getDates().getStartYear()== yearStart+i) {
					annual += s.getPayment().getRecievedPayment();
				}
			}
			str+=annual + "\n";
		}
		this.reportText=str;
	}
	
	public String getReport() {
		return reportText;
	}
	
}
