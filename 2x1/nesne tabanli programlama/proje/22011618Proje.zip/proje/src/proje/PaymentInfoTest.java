package proje;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class PaymentInfoTest {
	private PaymentInfo payment;
	@Before
	public void setUp() throws Exception {
		payment = new PaymentInfo(20);
		payment.increasePayment(100);
	}
	
	@Test
	public void testToString() {
		String str = "PaymentInfo [discountRatio=20.0, recievedPayment=100.0]";
		assertEquals(str,payment.toString());
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testIncreasePayment() {
		payment.increasePayment(100);
		assertEquals(200,payment.getRecievedPayment(),0.1);
	}


}
