package proje;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.FlowLayout;
import javax.swing.JDesktopPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.JSplitPane;
import javax.swing.border.TitledBorder;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JInternalFrame;
import java.awt.Font;
import javax.swing.UIManager;
import java.awt.SystemColor;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class GUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_17;
	private JTextField textField_18;
	private JTextField textField_19;
	private JTextField textField_20;
	private JTextField textField_21;
	private JTextField textField_22;
	private JTextField textField_23;
	private JTextField textField_24;
	private JTextField textField_25;
	private JTextField textField_26;
	private JTextField textField_27;
	private JTextField textField_28;
	private JTextField textField_29;
	private JTextField textField_30;
	private JTextField textField_31;
	private JTextField textField_32;
	private JTextField textField_33;
	private JTextField textField_34;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GUI() {
		Distributor dist = new Distributor();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1474, 1035);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JDesktopPane desktopPane = new JDesktopPane();
		desktopPane.setBounds(10, 10, 475, 300);
		contentPane.add(desktopPane);
		
		textField = new JTextField();
		textField.setBounds(93, 69, 96, 19);
		desktopPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Name:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(20, 70, 45, 13);
		desktopPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ISSN:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(20, 99, 45, 13);
		desktopPane.add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(93, 98, 96, 19);
		desktopPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(93, 128, 96, 19);
		desktopPane.add(textField_2);
		
		JLabel lblNewLabel_1_1 = new JLabel("frequency:");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(10, 126, 73, 18);
		desktopPane.add(lblNewLabel_1_1);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(93, 157, 96, 19);
		desktopPane.add(textField_3);
		
		JLabel lblNewLabel_1_2 = new JLabel("Issue Price:");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_2.setBounds(10, 154, 84, 18);
		desktopPane.add(lblNewLabel_1_2);
		
		JButton btnNewButton = new JButton("Create");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					dist.addJournal(new Journal(textField.getText(), textField_1.getText(),Integer.parseInt(textField_2.getText()) , Double.parseDouble(textField_3.getText())));

				}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "Wrong data", "ERROR", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnNewButton.setBounds(177, 222, 150, 54);
		desktopPane.add(btnNewButton);
		
		JLabel lblNewLabel_2 = new JLabel("Create Journal");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_2.setBounds(177, 21, 150, 25);
		desktopPane.add(lblNewLabel_2);
		
		JDesktopPane desktopPane_1 = new JDesktopPane();
		desktopPane_1.setBounds(495, 10, 467, 300);
		contentPane.add(desktopPane_1);
		
		JLabel lblNewLabel_3 = new JLabel("Create a new Subscriber");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_3.setBounds(158, 10, 209, 37);
		desktopPane_1.add(lblNewLabel_3);
		
		textField_4 = new JTextField();
		textField_4.setBounds(98, 56, 96, 19);
		desktopPane_1.add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Name:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_4.setBounds(35, 62, 78, 13);
		desktopPane_1.add(lblNewLabel_4);
		
		JLabel lblNewLabel_4_1 = new JLabel("Address:");
		lblNewLabel_4_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_4_1.setBounds(242, 58, 78, 13);
		desktopPane_1.add(lblNewLabel_4_1);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(317, 57, 96, 19);
		desktopPane_1.add(textField_5);
		
		JLabel lblNewLabel_5 = new JLabel("Individual");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_5.setBounds(72, 89, 87, 29);
		desktopPane_1.add(lblNewLabel_5);
		
		JLabel lblNewLabel_5_1 = new JLabel("Corporation");
		lblNewLabel_5_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_5_1.setBounds(314, 81, 87, 29);
		desktopPane_1.add(lblNewLabel_5_1);
		
		JLabel lblNewLabel_4_2 = new JLabel("Credit Card Number");
		lblNewLabel_4_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_4_2.setBounds(10, 134, 126, 13);
		desktopPane_1.add(lblNewLabel_4_2);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(133, 132, 96, 19);
		desktopPane_1.add(textField_6);
		
		JLabel lblNewLabel_4_1_1 = new JLabel("Exp Month");
		lblNewLabel_4_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_4_1_1.setBounds(10, 157, 78, 13);
		desktopPane_1.add(lblNewLabel_4_1_1);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(133, 157, 96, 19);
		desktopPane_1.add(textField_7);
		
		JLabel lblNewLabel_4_1_1_1 = new JLabel("Exp Year");
		lblNewLabel_4_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_4_1_1_1.setBounds(10, 180, 78, 13);
		desktopPane_1.add(lblNewLabel_4_1_1_1);
		
		textField_8 = new JTextField();
		textField_8.setColumns(10);
		textField_8.setBounds(133, 180, 96, 19);
		desktopPane_1.add(textField_8);
		
		JLabel lblNewLabel_4_1_1_2 = new JLabel("CCV");
		lblNewLabel_4_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_4_1_1_2.setBounds(10, 203, 78, 13);
		desktopPane_1.add(lblNewLabel_4_1_1_2);
		
		textField_9 = new JTextField();
		textField_9.setColumns(10);
		textField_9.setBounds(133, 203, 96, 19);
		desktopPane_1.add(textField_9);
		
		JLabel lblNewLabel_4_2_1 = new JLabel("Bank Code:");
		lblNewLabel_4_2_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_4_2_1.setBounds(252, 120, 126, 13);
		desktopPane_1.add(lblNewLabel_4_2_1);
		
		textField_10 = new JTextField();
		textField_10.setColumns(10);
		textField_10.setBounds(358, 119, 96, 19);
		desktopPane_1.add(textField_10);
		
		JLabel lblNewLabel_4_1_1_3 = new JLabel("Bank Name:");
		lblNewLabel_4_1_1_3.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_4_1_1_3.setBounds(252, 143, 96, 13);
		desktopPane_1.add(lblNewLabel_4_1_1_3);
		
		textField_11 = new JTextField();
		textField_11.setColumns(10);
		textField_11.setBounds(358, 144, 96, 19);
		desktopPane_1.add(textField_11);
		
		JLabel lblNewLabel_4_1_1_1_1 = new JLabel("Issue Day:");
		lblNewLabel_4_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_4_1_1_1_1.setBounds(252, 166, 78, 13);
		desktopPane_1.add(lblNewLabel_4_1_1_1_1);
		
		textField_12 = new JTextField();
		textField_12.setColumns(10);
		textField_12.setBounds(358, 167, 96, 19);
		desktopPane_1.add(textField_12);
		
		JLabel lblNewLabel_4_1_1_2_1 = new JLabel("Issue Month");
		lblNewLabel_4_1_1_2_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_4_1_1_2_1.setBounds(252, 189, 96, 13);
		desktopPane_1.add(lblNewLabel_4_1_1_2_1);
		
		textField_13 = new JTextField();
		textField_13.setColumns(10);
		textField_13.setBounds(358, 190, 96, 19);
		desktopPane_1.add(textField_13);
		
		textField_14 = new JTextField();
		textField_14.setColumns(10);
		textField_14.setBounds(358, 211, 96, 19);
		desktopPane_1.add(textField_14);
		
		JLabel lblNewLabel_4_1_1_2_1_1 = new JLabel("Account No");
		lblNewLabel_4_1_1_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_4_1_1_2_1_1.setBounds(252, 235, 96, 13);
		desktopPane_1.add(lblNewLabel_4_1_1_2_1_1);
		
		JLabel lblNewLabel_4_1_1_1_1_1 = new JLabel("Issue Year");
		lblNewLabel_4_1_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_4_1_1_1_1_1.setBounds(252, 212, 78, 13);
		desktopPane_1.add(lblNewLabel_4_1_1_1_1_1);
		
		textField_15 = new JTextField();
		textField_15.setColumns(10);
		textField_15.setBounds(358, 234, 96, 19);
		desktopPane_1.add(textField_15);
		
		JButton btnNewButton_1 = new JButton("Create");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					dist.addSubscriber(new Individual(textField_4.getText(), textField_5.getText(),textField_6.getText() ,Integer.parseInt(textField_7.getText()) , Integer.parseInt(textField_8.getText()), Integer.parseInt(textField_9.getText())));

				}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "Wrong data", "ERROR", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnNewButton_1.setBounds(74, 248, 85, 21);
		desktopPane_1.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Create");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					dist.addSubscriber(new Corporation(textField_4.getText(), textField_5.getText(),Integer.parseInt(textField_10.getText()) ,textField_11.getText() , Integer.parseInt(textField_12.getText()), Integer.parseInt(textField_13.getText()),Integer.parseInt(textField_14.getText()),Integer.parseInt(textField_15.getText())));
				}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "Wrong data", "ERROR", JOptionPane.ERROR_MESSAGE);
					//e1.printStackTrace();
				}
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnNewButton_2.setBounds(330, 265, 87, 19);
		desktopPane_1.add(btnNewButton_2);
		
		JDesktopPane desktopPane_2 = new JDesktopPane();
		desktopPane_2.setBounds(10, 320, 475, 217);
		contentPane.add(desktopPane_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("New Subscription");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_2_1.setBounds(151, 10, 150, 25);
		desktopPane_2.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_6 = new JLabel("Name:");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_6.setBounds(20, 46, 45, 13);
		desktopPane_2.add(lblNewLabel_6);
		
		textField_16 = new JTextField();
		textField_16.setColumns(10);
		textField_16.setBounds(93, 45, 96, 19);
		desktopPane_2.add(textField_16);
		
		JLabel lblNewLabel_1_3 = new JLabel("ISSN:");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_3.setBounds(20, 75, 45, 13);
		desktopPane_2.add(lblNewLabel_1_3);
		
		textField_17 = new JTextField();
		textField_17.setColumns(10);
		textField_17.setBounds(93, 74, 96, 19);
		desktopPane_2.add(textField_17);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Copies");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_1_1.setBounds(10, 102, 73, 18);
		desktopPane_2.add(lblNewLabel_1_1_1);
		
		textField_18 = new JTextField();
		textField_18.setColumns(10);
		textField_18.setBounds(93, 104, 96, 19);
		desktopPane_2.add(textField_18);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("Starting Month");
		lblNewLabel_1_2_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_2_1.setBounds(0, 131, 114, 18);
		desktopPane_2.add(lblNewLabel_1_2_1);
		
		textField_19 = new JTextField();
		textField_19.setColumns(10);
		textField_19.setBounds(93, 133, 96, 19);
		desktopPane_2.add(textField_19);
		
		textField_20 = new JTextField();
		textField_20.setColumns(10);
		textField_20.setBounds(93, 161, 96, 19);
		desktopPane_2.add(textField_20);
		
		JLabel lblNewLabel_1_2_1_1 = new JLabel("Starting Year");
		lblNewLabel_1_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_2_1_1.setBounds(0, 159, 114, 18);
		desktopPane_2.add(lblNewLabel_1_2_1_1);
		
		JButton btnNewButton_3 = new JButton("Create");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					dist.addSubscription(textField_17.getText(), dist.searchSubscriber(textField_16.getText()) ,new Subscription(new DateInfo(Integer.parseInt(textField_19.getText()), Integer.parseInt(textField_19.getText()) - 1, Integer.parseInt(textField_20.getText())),new PaymentInfo(Double.parseDouble(textField_21.getText())) ,Integer.parseInt(textField_18.getText()),dist.searchJournal(textField_17.getText()),dist.searchSubscriber(textField_16.getText())));
				}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "Wrong data", "ERROR", JOptionPane.ERROR_MESSAGE);
					//e1.printStackTrace();
				}
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton_3.setBounds(288, 90, 96, 33);
		desktopPane_2.add(btnNewButton_3);
		
		textField_21 = new JTextField();
		textField_21.setColumns(10);
		textField_21.setBounds(93, 190, 96, 19);
		desktopPane_2.add(textField_21);
		
		JLabel lblNewLabel_1_2_1_1_1 = new JLabel("Discount rate");
		lblNewLabel_1_2_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_2_1_1_1.setBounds(0, 188, 114, 18);
		desktopPane_2.add(lblNewLabel_1_2_1_1_1);
		
		JDesktopPane desktopPane_2_1 = new JDesktopPane();
		desktopPane_2_1.setBounds(495, 320, 467, 217);
		contentPane.add(desktopPane_2_1);
		
		JLabel lblNewLabel_2_2 = new JLabel("Payment");
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_2_2.setBounds(167, 10, 150, 25);
		desktopPane_2_1.add(lblNewLabel_2_2);
		
		JLabel lblNewLabel_6_1 = new JLabel("Name:");
		lblNewLabel_6_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_6_1.setBounds(20, 46, 45, 13);
		desktopPane_2_1.add(lblNewLabel_6_1);
		
		textField_22 = new JTextField();
		textField_22.setColumns(10);
		textField_22.setBounds(93, 45, 96, 19);
		desktopPane_2_1.add(textField_22);
		
		JLabel lblNewLabel_1_3_1 = new JLabel("ISSN:");
		lblNewLabel_1_3_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_3_1.setBounds(20, 75, 45, 13);
		desktopPane_2_1.add(lblNewLabel_1_3_1);
		
		textField_23 = new JTextField();
		textField_23.setColumns(10);
		textField_23.setBounds(93, 74, 96, 19);
		desktopPane_2_1.add(textField_23);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Amount:");
		lblNewLabel_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_1_1_1.setBounds(10, 102, 73, 18);
		desktopPane_2_1.add(lblNewLabel_1_1_1_1);
		
		textField_24 = new JTextField();
		textField_24.setColumns(10);
		textField_24.setBounds(93, 104, 96, 19);
		desktopPane_2_1.add(textField_24);
		
		JButton btnNewButton_3_1 = new JButton("Payment");
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = textField_22.getText();
				String issn = textField_23.getText();
				double amount = Double.parseDouble(textField_24.getText());
				
				try {
					dist.searchSubscription(name, issn).acceptPayment(amount);
				}
				catch(Exception e1){
					JOptionPane.showMessageDialog(null, "Wrong data", "ERROR", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnNewButton_3_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton_3_1.setBounds(67, 140, 96, 33);
		desktopPane_2_1.add(btnNewButton_3_1);
		
		JDesktopPane desktopPane_3 = new JDesktopPane();
		desktopPane_3.setBounds(10, 547, 952, 187);
		contentPane.add(desktopPane_3);
		
		JLabel lblNewLabel_7 = new JLabel("Subscriptions");
		lblNewLabel_7.setBounds(142, 0, 147, 35);
		desktopPane_3.add(lblNewLabel_7);
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 16));
		
		JLabel lblNewLabel_8 = new JLabel("Name");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_8.setBounds(26, 38, 100, 30);
		desktopPane_3.add(lblNewLabel_8);
		
		textField_25 = new JTextField();
		textField_25.setBounds(102, 44, 100, 19);
		desktopPane_3.add(textField_25);
		textField_25.setColumns(10);
		
		JLabel lblNewLabel_8_1 = new JLabel("ISSN");
		lblNewLabel_8_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_8_1.setBounds(26, 86, 100, 30);
		desktopPane_3.add(lblNewLabel_8_1);
		
		textField_26 = new JTextField();
		textField_26.setColumns(10);
		textField_26.setBounds(102, 92, 100, 19);
		desktopPane_3.add(textField_26);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(446, 25, 500, 150);
		desktopPane_3.add(scrollPane);
		
		JTextArea textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		
		JButton btnNewButton_4 = new JButton("Search by Subscrbier");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					textArea.setText(dist.listSubscriptions(textField_25.getText()));
				}
				catch(Exception e1){
					JOptionPane.showMessageDialog(null, "Wrong data", "ERROR", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnNewButton_4.setBounds(241, 40, 130, 30);
		desktopPane_3.add(btnNewButton_4);
		
		JButton btnNewButton_4_1 = new JButton("Search by Journal");
		btnNewButton_4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					textArea.setText(dist.listSubscriptionsISSN(textField_26.getText()));
				}
				catch(Exception e1){
					JOptionPane.showMessageDialog(null, "Wrong data", "ERROR", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnNewButton_4_1.setBounds(241, 85, 120, 30);
		desktopPane_3.add(btnNewButton_4_1);
		
		JDesktopPane desktopPane_3_1 = new JDesktopPane();
		desktopPane_3_1.setBounds(10, 744, 952, 254);
		contentPane.add(desktopPane_3_1);
		
		JLabel lblNewLabel_7_1 = new JLabel("Orders");
		lblNewLabel_7_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_7_1.setBounds(142, 0, 147, 35);
		desktopPane_3_1.add(lblNewLabel_7_1);
		
		JLabel lblNewLabel_8_2 = new JLabel("ISSN");
		lblNewLabel_8_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_8_2.setBounds(26, 38, 100, 30);
		desktopPane_3_1.add(lblNewLabel_8_2);
		
		textField_27 = new JTextField();
		textField_27.setColumns(10);
		textField_27.setBounds(102, 44, 100, 19);
		desktopPane_3_1.add(textField_27);
		
		JLabel lblNewLabel_8_1_1 = new JLabel("Month");
		lblNewLabel_8_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_8_1_1.setBounds(26, 86, 100, 30);
		desktopPane_3_1.add(lblNewLabel_8_1_1);
		
		textField_28 = new JTextField();
		textField_28.setColumns(10);
		textField_28.setBounds(102, 92, 100, 19);
		desktopPane_3_1.add(textField_28);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(398, 21, 544, 223);
		desktopPane_3_1.add(scrollPane_1);
		
		JTextArea textArea_1 = new JTextArea();
		scrollPane_1.setViewportView(textArea_1);
		
		JButton btnNewButton_4_2 = new JButton("List Orders");
		btnNewButton_4_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					textArea_1.setText(dist.listSendingOrders(textField_27.getText(), Integer.parseInt(textField_28.getText()), Integer.parseInt(textField_29.getText())));
				}
				catch(Exception e1){
					JOptionPane.showMessageDialog(null, "Wrong data", "ERROR", JOptionPane.ERROR_MESSAGE);
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_4_2.setBounds(241, 40, 130, 30);
		desktopPane_3_1.add(btnNewButton_4_2);
		

		
		
		JButton btnNewButton_4_1_1 = new JButton("Incomplete Payments");
		btnNewButton_4_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					textArea_1.setText(dist.listIncompletePayments());
				}
				catch(Exception e1){
					JOptionPane.showMessageDialog(null, "Wrong data", "ERROR", JOptionPane.ERROR_MESSAGE);
					e1.printStackTrace();
				}
			}
			}
		);
		btnNewButton_4_1_1.setBounds(241, 136, 147, 30);
		desktopPane_3_1.add(btnNewButton_4_1_1);
		
	
		
		
		JLabel lblNewLabel_8_1_1_1 = new JLabel("Year");
		lblNewLabel_8_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_8_1_1_1.setBounds(26, 134, 100, 30);
		desktopPane_3_1.add(lblNewLabel_8_1_1_1);
		
		textField_29 = new JTextField();
		textField_29.setColumns(10);
		textField_29.setBounds(102, 142, 100, 19);
		desktopPane_3_1.add(textField_29);
		
		JButton btnNewButton_4_2_1 = new JButton("List ALL Orders");
		btnNewButton_4_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					textArea_1.setText(dist.listAllSendingOrders(Integer.parseInt(textField_28.getText()), Integer.parseInt(textField_29.getText())));
				}
				catch(Exception e1){
					JOptionPane.showMessageDialog(null, "Wrong data", "ERROR", JOptionPane.ERROR_MESSAGE);
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_4_2_1.setBounds(241, 93, 130, 30);
		desktopPane_3_1.add(btnNewButton_4_2_1);
		
		JDesktopPane desktopPane_4 = new JDesktopPane();
		desktopPane_4.setBounds(972, 10, 476, 985);
		contentPane.add(desktopPane_4);
		
		JLabel lblNewLabel_10 = new JLabel("Report");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_10.setBounds(214, 11, 79, 42);
		desktopPane_4.add(lblNewLabel_10);
		
		textField_31 = new JTextField();
		textField_31.setColumns(10);
		textField_31.setBounds(86, 56, 100, 19);
		desktopPane_4.add(textField_31);
		
		JLabel lblNewLabel_8_1_1_2 = new JLabel("Month");
		lblNewLabel_8_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_8_1_1_2.setBounds(10, 50, 100, 30);
		desktopPane_4.add(lblNewLabel_8_1_1_2);
		
		JLabel lblNewLabel_8_1_1_1_1 = new JLabel("Year");
		lblNewLabel_8_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_8_1_1_1_1.setBounds(10, 98, 100, 30);
		desktopPane_4.add(lblNewLabel_8_1_1_1_1);
		
		textField_32 = new JTextField();
		textField_32.setColumns(10);
		textField_32.setBounds(86, 106, 100, 19);
		desktopPane_4.add(textField_32);
		
		textField_33 = new JTextField();
		textField_33.setColumns(10);
		textField_33.setBounds(366, 62, 100, 19);
		desktopPane_4.add(textField_33);
		
		JLabel lblNewLabel_8_1_1_3 = new JLabel("Start Year");
		lblNewLabel_8_1_1_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_8_1_1_3.setBounds(290, 56, 100, 30);
		desktopPane_4.add(lblNewLabel_8_1_1_3);
		
		JLabel lblNewLabel_8_1_1_1_2 = new JLabel("End Year");
		lblNewLabel_8_1_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_8_1_1_1_2.setBounds(290, 104, 100, 30);
		desktopPane_4.add(lblNewLabel_8_1_1_1_2);
		
		textField_34 = new JTextField();
		textField_34.setColumns(10);
		textField_34.setBounds(366, 112, 100, 19);
		desktopPane_4.add(textField_34);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(10, 209, 456, 504);
		desktopPane_4.add(scrollPane_2);
		
		JTextArea textArea_1_1 = new JTextArea();
		scrollPane_2.setViewportView(textArea_1_1);
		
		JButton btnNewButton_4_2_2 = new JButton("Report");
		btnNewButton_4_2_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					dist.report(Integer.parseInt(textField_31.getText()),Integer.parseInt(textField_32.getText()),Integer.parseInt(textField_33.getText()),Integer.parseInt(textField_34.getText()));
					Thread th = new Thread(dist);
					th.start();
					textArea_1_1.setText(dist.getReport());
				}
				catch(Exception e1){
					JOptionPane.showMessageDialog(null, "Wrong data", "ERROR", JOptionPane.ERROR_MESSAGE);
					e1.printStackTrace();
				}
			
			}
		});
		btnNewButton_4_2_2.setBounds(184, 145, 130, 30);
		desktopPane_4.add(btnNewButton_4_2_2);
		
		JLabel lblNewLabel_10_1 = new JLabel("Expire");
		lblNewLabel_10_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_10_1.setBounds(10, 11, 79, 42);
		desktopPane_4.add(lblNewLabel_10_1);
		
		JLabel lblNewLabel_10_1_1 = new JLabel("Income");
		lblNewLabel_10_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_10_1_1.setBounds(366, 11, 79, 42);
		desktopPane_4.add(lblNewLabel_10_1_1);
		
		JButton btnNewButton_5 = new JButton("SAVE");
		btnNewButton_5.setBounds(84, 735, 102, 54);
		desktopPane_4.add(btnNewButton_5);
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				   try {
					   	dist.saveState(textField_30.getText());
			        } catch (Exception e1) {
			            e1.printStackTrace();
			        }
			}
		});
		btnNewButton_5.setFont(new Font("Tahoma", Font.PLAIN, 16));
		
		JButton btnNewButton_5_1 = new JButton("LOAD");
		btnNewButton_5_1.setBounds(214, 735, 102, 54);
		desktopPane_4.add(btnNewButton_5_1);
		btnNewButton_5_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        try {
		            dist.loadState(textField_30.getText());
		        } catch (Exception i) {
		            i.printStackTrace();
		            return;
		        } 
			}
		});
		btnNewButton_5_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		
		textField_30 = new JTextField();
		textField_30.setBounds(95, 812, 92, 19);
		desktopPane_4.add(textField_30);
		textField_30.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("File Name:");
		lblNewLabel_9.setBounds(10, 800, 92, 40);
		desktopPane_4.add(lblNewLabel_9);
		lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 16));
		

	}
}
