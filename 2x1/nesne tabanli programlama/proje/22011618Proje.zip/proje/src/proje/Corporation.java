package proje;

import java.io.Serializable;

public class Corporation extends Subscriber implements Serializable{
	private int bankCode;
	private String bankName;
	private int issueDay;
	private int issueMonth;
	private int issueYear;
	private int accountNumber;
	
	public Corporation(String name, String address, int bankCode, String bankName, int issueDay, int issueMonth,
			int issueYear, int accountNumber) {
		super(name, address);
		this.bankCode = bankCode;
		this.bankName = bankName;
		this.issueDay = issueDay;
		this.issueMonth = issueMonth;
		this.issueYear = issueYear;
		this.accountNumber = accountNumber;
	}
	
	@Override
	public String getBillingInformation() {
		return "Corporation [Name:" + getName() + ", Address:" + getAddress() + ", bankCode=" + bankCode
				+ ", bankName=" + bankName + ", issueDay=" + issueDay + ", issueMonth=" + issueMonth + ", issueYear="
				+ issueYear + ", accountNumber=" + accountNumber + "]";
	}
	
	
}
