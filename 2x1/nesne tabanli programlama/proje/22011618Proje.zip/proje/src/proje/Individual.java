package proje;

import java.io.Serializable;

public class Individual extends Subscriber implements Serializable{
	private String creditCardNr;
	private int expireMonth;
	private int expireYear;
	private int CCV;
	
	public Individual(String name, String address,String ccNr, int expM, int expY, int CCV) {
		super(name, address);
		this.creditCardNr=ccNr;
		this.expireMonth=expM;
		this.expireYear=expY;
		this.CCV=CCV;
	}

	@Override
	public String getBillingInformation() {
		return "Name =" + getName() + "Address = " + "Individual [creditCardNr=" + creditCardNr + ", expireMonth=" + expireMonth + ", expireYear="
				+ expireYear + ", CCV=" + CCV + "]";
	}
	
}
