package proje;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class JournalTest {
	private Journal j;
	@Before
	public void setUp() throws Exception {
		j = new Journal("Dergi", "123",3,100);
	}

	@Test
	public void testJournal() {
		assertEquals("Dergi",j.getName());
		assertEquals("123",j.getIssn());
		assertEquals(3,j.getFrequency());

	}

	@Test
	public void testToString() {
		String str = "Journal [name=Dergi, issn=123, frequency=3, issuePrice=100.0]";
		assertEquals(str,j.toString());
	}

}
