package proje;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class DateInfoTest {
	private DateInfo date;
	
	@Before
	public void setUp() throws Exception {
		date = new DateInfo(8,7,2023);
	}

	@Test
	public void testDateInfo() {
		assertEquals(8,date.getStartMonth());
		assertEquals(7,date.getEndMonth());
		assertEquals(2023,date.getStartYear());
	}

	@Test
	public void testToString() {
		String str = "startMonth=8, endMonth=7, startYear=2023";
		assertEquals(str,date.toString());
	}

}
