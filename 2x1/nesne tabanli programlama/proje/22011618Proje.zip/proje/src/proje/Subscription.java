package proje;

import java.io.Serializable;

public class Subscription implements Serializable{
	private final DateInfo dates;
	private PaymentInfo payment;
	private int copies;
	private final Journal journal;
	private final Subscriber subscriber;
	public Subscription(DateInfo dates, PaymentInfo payment, int copies, Journal journal, Subscriber subscriber) {
		this.dates = dates;
		this.payment = payment;
		this.copies = copies;
		this.journal = journal;
		this.subscriber = subscriber;
	}
	public void acceptPayment(double amount) {
		if(payment.getRecievedPayment()< journal.getFrequency() * journal.getIssuePrice()*(100-payment.getDiscountRatio())/100) {
			payment.increasePayment(amount);
		}
	}
	
	public boolean canSend(int issueMonth) {
		if(issueMonth % (12/journal.getFrequency()) != 0) {
			return false;
		}
		if(dates.getStartMonth()<=issueMonth) {
			if(((int)((issueMonth-dates.getStartMonth()) / (12 / journal.getFrequency())+1) * copies * journal.getIssuePrice()*(100-payment.getDiscountRatio())/100<=payment.getRecievedPayment())) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			if((int)((12+issueMonth-dates.getEndMonth()) / (12 / journal.getFrequency())) * copies * journal.getIssuePrice()*(100-payment.getDiscountRatio())/100<=payment.getRecievedPayment()) {
				return true;
			}
			else {
				return false;
			}
		}
		
	}
	public PaymentInfo getPayment() {
		return payment;
	}
	public void setPayment(PaymentInfo payment) {
		this.payment = payment;
	}
	public int getCopies() {
		return copies;
	}
	public void setCopies(int copies) {
		this.copies = copies;
	}
	public DateInfo getDates() {
		return dates;
	}
	public Journal getJournal() {
		return journal;
	}
	public Subscriber getSubscriber() {
		return subscriber;
	}
	@Override
	public String toString() {
		return subscriber + ", "+ dates +  ", copies=" + copies + ", journal=" + journal;
				
	}
	

	
	
}
