package proje;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class IndividualTest {
	private Individual person;
	@Before
	public void setUp() throws Exception {
		person = new Individual("Ahmet", "Istanbul", "12345", 8,2027,532);
	}

	@Test
	public void testGetBillingInformation() {
		String str = "Name =AhmetAddress = Individual [creditCardNr=12345, expireMonth=8, expireYear=2027, CCV=532]";
		assertEquals(str,person.getBillingInformation());
	}

	@Test
	public void testToString() {
		String str = "name=Ahmet, address=Istanbul";
		assertEquals(str,person.toString());
	}

}
